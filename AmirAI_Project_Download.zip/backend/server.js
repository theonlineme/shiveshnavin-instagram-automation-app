import express from "express";
import "dotenv/config";

const app = express();
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => res.json({ app: "Amir AI backend", status: "ok" }));

app.post("/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Message is required" });
    if (message.length > 12000) return res.status(400).json({ error: "Message too long" });
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "Server API key is not configured" });

    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        instructions: "You are Amir AI, a helpful, accurate assistant. Reply in the user's language. Be clear and safe.",
        input: message
      })
    });

    const data = await upstream.json();
    if (!upstream.ok) {
      console.error("AI provider error:", data);
      return res.status(502).json({ error: "AI provider request failed" });
    }
    const reply = data.output_text || (data.output || [])
      .flatMap(item => item.content || [])
      .filter(part => part.type === "output_text")
      .map(part => part.text).join("\n");
    return res.json({ reply: reply || "No response was returned." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Unexpected server error" });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Amir AI backend listening on ${port}`));

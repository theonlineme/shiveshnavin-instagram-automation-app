package com.amirai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF151D32)
private val Accent = Color(0xFF8B7CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmirAIApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)

@Composable
fun AmirAIApp() {
    val messages = remember {
        mutableStateListOf(ChatMessage("হ্যালো! আমি Amir AI। কীভাবে সাহায্য করতে পারি?", false))
    }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, background = Ink, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Ink).statusBarsPadding().navigationBarsPadding()
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(42.dp).background(Accent, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("A", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Amir AI", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Your smart AI assistant", fontSize = 12.sp, color = Color(0xFFADB7D0))
                }
                Text("● Online", color = Color(0xFF65D6A2), fontSize = 12.sp)
            }
            HorizontalDivider(color = Color(0xFF28314A))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Column(
                            Modifier.widthIn(max = 310.dp)
                                .background(
                                    if (msg.fromUser) Color(0xFF5145B8) else Panel,
                                    RoundedCornerShape(18.dp)
                                ).padding(14.dp)
                        ) {
                            Text(if (msg.fromUser) "You" else "Amir AI",
                                color = Color(0xFFC9C4FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(msg.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp)
                        }
                    }
                }
                if (loading) item {
                    Text("Amir AI is thinking…", color = Color(0xFFADB7D0), modifier = Modifier.padding(8.dp))
                }
            }
            error?.let {
                Text(it, color = Color(0xFFFF8C8C), modifier = Modifier.padding(horizontal = 16.dp))
            }
            Row(
                Modifier.fillMaxWidth().background(Panel).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("মেসেজ লিখুন…", color = Color(0xFF929DB8)) },
                    shape = RoundedCornerShape(22.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF3B4663),
                        cursorColor = Accent
                    ),
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        val prompt = input.trim()
                        if (prompt.isNotEmpty() && !loading) {
                            messages.add(ChatMessage(prompt, true))
                            input = ""; error = null; loading = true
                            scope.launch {
                                try {
                                    val answer = askAmirAI(prompt)
                                    messages.add(ChatMessage(answer, false))
                                } catch (e: Exception) {
                                    error = "সংযোগ করা যাচ্ছে না। Backend URL ও ইন্টারনেট পরীক্ষা করুন।"
                                } finally { loading = false }
                            }
                        }
                    },
                    enabled = !loading && input.isNotBlank(),
                    modifier = Modifier.size(52.dp).background(Accent, RoundedCornerShape(18.dp))
                ) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White) }
            }
            Text("AI উত্তর ভুল হতে পারে—গুরুত্বপূর্ণ তথ্য যাচাই করুন।",
                color = Color(0xFF77839F), fontSize = 10.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 7.dp))
        }
    }
}

private suspend fun askAmirAI(message: String): String =
    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        // Replace with your deployed HTTPS backend URL.
        val backendUrl = "https://YOUR-BACKEND-DOMAIN.example.com/chat"
        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS).build()
        val json = JSONObject().put("message", message)
        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url(backendUrl).post(body).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("HTTP ${response.code}")
            val result = JSONObject(response.body?.string() ?: "{}")
            result.optString("reply", "দুঃখিত, উত্তর পাওয়া যায়নি।")
        }
    }

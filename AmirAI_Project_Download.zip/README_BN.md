# Amir AI — Android + Real AI Backend

এটি একটি Android Studio প্রজেক্টের প্রাথমিক সম্পূর্ণ সোর্স এবং আলাদা Node.js backend।
Android অ্যাপে কখনো API key রাখবেন না। API key শুধু backend-এর environment variable-এ থাকবে।

## যা আছে
- Kotlin + Jetpack Compose Android UI
- বাংলা/ইংরেজি টেক্সট চ্যাট
- আলাদা HTTPS backend
- Backend থেকে OpenAI Responses API কল
- API key অ্যাপের APK-তে প্রকাশ না করে সার্ভারে রাখা

## ১) Backend চালু করা
Node.js 20 বা নতুন সংস্করণ ব্যবহার করুন।

```bash
cd backend
npm install
cp .env.example .env
```

`.env` ফাইলে আপনার API key বসান। `.env` কখনো GitHub-এ আপলোড করবেন না।

```bash
npm start
```

লোকাল টেস্টে `http://localhost:3000` চালু হবে। ফোনের APK-তে localhost ব্যবহার করা যাবে না।
Backend-টি HTTPS সমর্থিত hosting-এ deploy করুন (যেমন Render, Railway বা আপনার নিজস্ব server)।
Hosting-এর Environment Variables-এ `OPENAI_API_KEY` এবং চাইলে `OPENAI_MODEL` সেট করুন।

## ২) Android app-এ backend URL বসানো
`app/src/main/java/com/amirai/app/MainActivity.kt` খুলুন।
`https://YOUR-BACKEND-DOMAIN.example.com/chat` বদলে আপনার deployed HTTPS URL দিন।
উদাহরণ: `https://amir-ai-api.example.com/chat`

## ৩) Android Studio থেকে APK
1. Android Studio-তে এই `AmirAI` ফোল্ডার Open করুন।
2. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
3. JDK 17 ব্যবহার করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. সফল হলে `app/build/outputs/apk/debug/app-debug.apk` তৈরি হবে।
6. নিজের ফোনে পরীক্ষা করার জন্য APK কপি করে ইনস্টল করুন।

Release APK:
Build > Generate Signed Bundle / APK > APK নির্বাচন করুন। নতুন keystore তৈরি করে নিরাপদে সংরক্ষণ করুন।
Keystore বা password কাউকে দেবেন না।

## ৪) গুরুত্বপূর্ণ
- Real AI ব্যবহারে API provider-এর account, API key, internet এবং usage billing লাগতে পারে।
- API key গোপন রাখুন; APK বা public GitHub repository-তে রাখবেন না।
- API usage limit, authentication, rate limiting এবং abuse protection production launch-এর আগে যোগ করুন।
- এই starter project-এ chat history device-এ স্থায়ীভাবে সংরক্ষণ করা হয় না।
- AI উত্তর ভুল হতে পারে। গুরুত্বপূর্ণ তথ্য যাচাই করুন।
